package com.spring.autowiring;
import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.*;
@SuppressWarnings("deprecation")
public class TestBase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource r = new ClassPathResource("wiring.xml");
		BeanFactory factory = new XmlBeanFactory(r);
		Base2 s = (Base2) factory.getBean("base2");
		s.base2display();
	}
}
