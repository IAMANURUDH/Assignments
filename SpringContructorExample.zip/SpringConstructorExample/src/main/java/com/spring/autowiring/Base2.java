package com.spring.autowiring;

public class Base2 {
	Base1 b;// where b is reference of base1 class

	Base2() {
		System.out.println("Base2");
	}

	public Base1 getB() {
		return b;
	}

	public void setB(Base1 b) {
		this.b = b;
	}

	public void base2display() {
		System.out.println("Base2 Display");
		b.display();
	}
}
