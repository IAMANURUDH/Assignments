package com.spring.autowiring;

public class Base1 {

	public Base1() {
		System.out.println("Base1");
	}

	public void display() {
		System.out.println("Base1 Display");
	}
}
