package com.set.setter;

import java.util.HashSet;
import java.util.Set;

public class SetExample {
	@SuppressWarnings("unused")
	private String fullName;
	@SuppressWarnings("rawtypes")
	private Set st;
	public SetExample() {
	}
	public SetExample(String name, @SuppressWarnings("rawtypes") HashSet hs) {
		super();
		fullName = name;
		st = hs;
	}
	public void display(){
		System.out.println(st);
	}
}
