package com.set.setter;

import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.*; 

@SuppressWarnings("deprecation")
public class TestSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource r = new ClassPathResource("utils.xml");
		BeanFactory factory = new XmlBeanFactory(r);
		SetExample s = (SetExample) factory.getBean("st");
		s.display();
	}
}
