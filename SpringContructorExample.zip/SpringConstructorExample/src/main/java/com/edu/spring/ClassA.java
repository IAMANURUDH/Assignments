package com.edu.spring;

public class ClassA {
	private int a;
	private int b;
	
	public ClassA(int a, int b) {
		super();
		this.a = a;
		this.b = b;
	}

	public void add() {
		System.out.println(a+b);
	}
}

