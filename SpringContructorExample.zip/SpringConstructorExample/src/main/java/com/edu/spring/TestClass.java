/**
 * 
 */
package com.edu.spring;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.*; 
/**
 * @author Anurudh Gupta
 */
@SuppressWarnings({ "unused", "deprecation" })
public class TestClass {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource r=new ClassPathResource("applicationContext.xml");  
		BeanFactory factory=new XmlBeanFactory(r);  
        ClassA s=(ClassA)factory.getBean("add");
        System.out.print("Addition of a and b is ");
        s.add(); 
        ClassB s1=(ClassB)factory.getBean("sub");
        System.out.print("Subtraction of a and b is ");
        s1.sub();
	}
}
