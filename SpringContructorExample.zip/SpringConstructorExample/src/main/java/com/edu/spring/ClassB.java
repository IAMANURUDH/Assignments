package com.edu.spring;

public class ClassB {
	private int a;
	private int b;

	public ClassB(int a, int b) {
		super();
		this.a = a;
		this.b = b;
	}

	public void sub() {
		System.out.println(a-b);
	}
}
