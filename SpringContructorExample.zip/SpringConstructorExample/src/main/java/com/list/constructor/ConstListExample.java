package com.list.constructor;

import java.util.List;
import java.util.ArrayList;

public class ConstListExample {
	// TODO Auto-generated method stub
	@SuppressWarnings("unused")
	private String fullName;
	@SuppressWarnings("rawtypes")
	private List ls;

	ConstListExample() {
	}

	ConstListExample(String name, @SuppressWarnings("rawtypes") ArrayList m) {
		fullName = name;
		ls = m;
	}

	public void display() {
		System.out.println(ls);
	}
}
