package com.list.constructor;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.*; 

@SuppressWarnings({ "unused", "deprecation" })
public class TestList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource r=new ClassPathResource("utils.xml");  
		BeanFactory factory=new XmlBeanFactory(r);  
        ConstListExample s=(ConstListExample)factory.getBean("ls");
        s.display();
	}
}
