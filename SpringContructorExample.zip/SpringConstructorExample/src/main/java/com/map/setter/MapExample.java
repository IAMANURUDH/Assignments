package com.map.setter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SuppressWarnings("unused")
public class MapExample {
	private String fullName;
	@SuppressWarnings("rawtypes")
	private Map mp;

	MapExample() {
	}

	MapExample(String name, @SuppressWarnings("rawtypes") HashMap m) {
		fullName = name;
		mp = m;
	}

	public void display() {
		System.out.println(mp);
	}
}
