package com.map.setter;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.*;

@SuppressWarnings({ "unused", "deprecation" })
public class TestMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource r = new ClassPathResource("utils.xml");
		BeanFactory factory = new XmlBeanFactory(r);
		MapExample s = (MapExample) factory.getBean("mp");
		s.display();
	}
}
