package com.web;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class LoginController {

	@RequestMapping("/login")
	public ModelAndView login(HttpServletRequest request,HttpServletResponse response) {
		System.out.println("Login Controller");
		String username= request.getParameter("userName");
		String password= request.getParameter("passWord");
		if(username.length()==0 || username.equals("")) {
			return new ModelAndView("errorPage","message","Invalid username or password");
		}
		else if(username.equals("Anurudh") && password.equals("anurudh")){
			return new ModelAndView("successPage","message","welcome user");
		}
		else {
			return new ModelAndView("welcome","message","Welcome");
		}
	}
}
