/**
 * 
 */
package trialproject;

/**
 * @author Anurudh Gupta
 *
 */
class UserThread1 extends Thread{
	public void run() {
		System.out.println("User Thread 1 Started....");
	}
}
public class ThreadExampleTwo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserThread1 ut = new UserThread1();
		UserThread1 ut1 = new UserThread1();
		ut.setName("Srinivas");
		ut1.setName("Hughes");
		
		ut1.start();
		try {
			ut1.join();
			ut.start();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
