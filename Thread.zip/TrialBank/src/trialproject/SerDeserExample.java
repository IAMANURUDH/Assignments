package trialproject;

import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.FileOutputStream;
class Game implements Serializable
{
	String name = "Srinivas";
}
public class SerDeserExample{

	//transient int a = 90;//this cannot be serialized.
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game gm = new Game();
		try
		{
			FileOutputStream fout = new FileOutputStream("abcd.txt");
			ObjectOutputStream o = new ObjectOutputStream(fout);
			o.writeObject(gm);
			o.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
