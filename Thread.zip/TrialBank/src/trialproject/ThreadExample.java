/**
 * 
 */
package trialproject;
/**
 * @author Anurudh Gupta
 */
class UserThread extends Thread
{
	public void run()
	{
		try {
			for(int i=0;i<10;i++)
			{
			Thread.sleep(1000);
			System.out.println(this.getName() + " " + i);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println("Thread Started..."+this.getName()+this.getId());
	}
}

public class ThreadExample {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		try {
//			Thread.sleep(100000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		UserThread th = new UserThread();
		th.setName("Anurudh");
		th.setPriority(1);
		th.start();
		UserThread th1 = new UserThread();
		th1.setName("Gupta");
		//th1.setPriority(10);
		//start method will internally call run on backend.
		th1.start();
	}
}
