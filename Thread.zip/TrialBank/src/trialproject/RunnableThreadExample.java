/**
 * 
 */
package trialproject;

/**
 * @author T00782
 *
 */
public class RunnableThreadExample implements Runnable {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new RunnableThreadExample().run();
	}

	// TODO Auto-generated method stub
	public void run() {
		System.out.println("Thread Started");
	}
}
