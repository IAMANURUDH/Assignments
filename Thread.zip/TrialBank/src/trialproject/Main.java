package trialproject;
import java.util.Random;
import java.util.Scanner;
// Superclass Transaction
class Transaction {
   protected double amount;
   public Transaction(double amount) {
       this.amount = amount;
   }
   public void depositAmount(double deposit) {
       amount += deposit;
   }
   public void withdrawAmount(double withdrawal) {
       amount -= withdrawal;
   }
   public void payLoan(double payment) {
       amount -= payment;
   }
   public void showAccountDetails() {
       System.out.println("Account Balance: $" + amount);
   }
}
// Subclass Loan inheriting from Transaction
class Loan extends Transaction {
   private String loanId;
   private String loanType;
   public Loan(String loanType, double amount) {
       super(amount);
       this.loanId = generateLoanId();
       this.loanType = loanType;
   }
   public void showLoanDetails() {
       System.out.println("Loan ID: " + loanId);
       System.out.println("Loan Type: " + loanType);
       System.out.println("Loan Amount: $" + amount);
   }
   private String generateLoanId() {
       // Generate a random UUID and return the first 8 characters
       return "LN-" + new Random().nextInt(10000); // Random loan id with prefix "LN-"
   }
}
// Subclass Account inheriting from Loan
class Account extends Loan {
   private String accountId;
   private String accountName;
   private String address;
   public Account(String accountName, String address, int loanId, String loanType, double amount) {
       super(loanType, amount);
       this.accountId = generateAccountId();
       this.accountName = accountName;
       this.address = address;
   }
   public void getDetails() {
       System.out.println("Account ID: " + accountId);
       System.out.println("Account Name: " + accountName);
       System.out.println("Address: " + address);
   }
   public void showDetails() {
       getDetails();
       showLoanDetails();
       showAccountDetails();
   }
   private String generateAccountId() {
       // Generate a random accountId with 7 digits followed by 4 capital letters
       Random random = new Random();
       StringBuilder accountIdBuilder = new StringBuilder();
       // Add 7 digits
       for (int i = 0; i < 7; i++) {
           accountIdBuilder.append(random.nextInt(10)); // Random digit between 0 and 9
       }
       // Add 4 capital letters
       for (int i = 0; i < 4; i++) {
           accountIdBuilder.append((char) (random.nextInt(26) + 'A')); // Random capital letter
       }
       return accountIdBuilder.toString();
   }
}
public class Main {
   public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
       System.out.println("Enter details for the Account:");
       System.out.print("Account Name: ");
       String accountName = scanner.nextLine();
       System.out.print("Address: ");
       String address = scanner.nextLine();
       System.out.print("Loan Type (Home/Car): ");
       String loanType = scanner.nextLine();
       System.out.print("Amount: ");
       double amount = scanner.nextDouble();
       Account account = new Account(accountName, address, 123, loanType, amount); // Dummy loanId as 123
       account.showDetails();
       scanner.close(); // Close the scanner object
   }
}