package com.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.model.Users;
import com.assignment.service.UserService;

@RestController
public class UserController {

	@Autowired
	UserService userService;
	
	@GetMapping("/getuser")
	public List<Users> readUsers(){
		return userService.getUsers();
	}
	
	@PostMapping("/insertuser")
	public Users insertUsers(@RequestBody Users user) {
		return userService.insertUsers(user);
	}
}
