package com.edu.JunitBasics;

public class Ttest {

	public static void MyConnection() {
		for(int i=0;;i++) {
			System.out.println("......");
		}
	}
}
