package com.edu.JunitBasics;

import org.junit.Ignore;
import org.junit.Test;

public class Ttest1 {

	@Test(timeout=100)
	public void ttest() 
	{
		Ttest.MyConnection();
	}
	@Ignore
	@Test(timeout=100)
	public void ttest1() 
	{
		Ttest.MyConnection();
	}
	@Test(timeout=100)
	public void ttest2() 
	{
		Ttest.MyConnection();
	}
}
