package com.edu.JunitBasics;

import org.junit.Test;
import junit.framework.Assert;

public class CalcultorTest {

	String message = "Anurudh";
	
	@Test
	public void addTest()
	{
		Assert.assertEquals(4,new Calculator().add(2, 2));
	}
	@Test
	public void subTest()
	{
		Assert.assertEquals(2,new Calculator().sub(2, 2));
	}
	
	@Test(expected=ArithmeticException.class)
	public void testPrintMessage() 
	{
		int a = 1/0;
		System.out.println("Inside testPrintMessage()");
	}
}
